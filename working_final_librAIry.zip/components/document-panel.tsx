"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  X,
  Download,
  Share,
  Edit,
  FileText,
  Image,
  Code,
  Video,
  Music,
  Bookmark,
  MessageSquare,
  Sparkles,
  Copy,
  Merge,
  HighlighterIcon as Highlight,
} from "lucide-react"
import type { FileItem } from "@/app/page"

interface DocumentPanelProps {
  file: FileItem | null
  onClose: () => void
}

const mockAnnotations = [
  {
    id: "1",
    text: "Important deadline mentioned here",
    timestamp: "2 hours ago",
    position: { x: 45, y: 23 },
  },
  {
    id: "2",
    text: "Need to follow up on this section",
    timestamp: "1 day ago",
    position: { x: 60, y: 45 },
  },
]

const mockSummary = `This document contains a comprehensive project proposal for the Q4 marketing campaign. Key points include:

• Budget allocation of $50,000 for digital advertising
• Timeline spanning October to December 2024
• Target audience: 25-45 year olds in urban areas
• Expected ROI of 150% based on previous campaigns
• Integration with existing CRM systems required

The proposal emphasizes data-driven decision making and includes detailed analytics tracking for campaign performance measurement.`

const mockHighlights = [
  "Budget allocation of $50,000",
  "Timeline spanning October to December 2024",
  "Expected ROI of 150%",
  "Integration with existing CRM systems",
]

export function DocumentPanel({ file, onClose }: DocumentPanelProps) {
  const [activeTab, setActiveTab] = useState<"content" | "annotations" | "ai-tools">("content")
  const [newAnnotation, setNewAnnotation] = useState("")
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false)

  if (!file) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <div className="text-center">
          <FileText className="w-12 h-12 mx-auto mb-4" />
          <p>Select a file to view its content</p>
        </div>
      </div>
    )
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "document":
        return <FileText className="w-5 h-5" />
      case "image":
        return <Image className="w-5 h-5" />
      case "code":
        return <Code className="w-5 h-5" />
      case "video":
        return <Video className="w-5 h-5" />
      case "audio":
        return <Music className="w-5 h-5" />
      default:
        return <FileText className="w-5 h-5" />
    }
  }

  const generateSummary = () => {
    setIsGeneratingSummary(true)
    setTimeout(() => {
      setIsGeneratingSummary(false)
    }, 2000)
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-muted rounded">{getFileIcon(file.type)}</div>
          <div>
            <h2 className="font-semibold">{file.name}</h2>
            <p className="text-sm text-muted-foreground">
              {file.size} • {file.modified} • {file.path}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button variant="outline" size="sm">
            <Share className="w-4 h-4 mr-2" />
            Share
          </Button>
          <Button variant="outline" size="sm">
            <Bookmark className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b">
        <Button
          variant={activeTab === "content" ? "default" : "ghost"}
          size="sm"
          onClick={() => setActiveTab("content")}
          className="rounded-none"
        >
          Content
        </Button>
        <Button
          variant={activeTab === "annotations" ? "default" : "ghost"}
          size="sm"
          onClick={() => setActiveTab("annotations")}
          className="rounded-none"
        >
          <MessageSquare className="w-4 h-4 mr-2" />
          Annotations ({mockAnnotations.length})
        </Button>
        <Button
          variant={activeTab === "ai-tools" ? "default" : "ghost"}
          size="sm"
          onClick={() => setActiveTab("ai-tools")}
          className="rounded-none"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          AI Tools
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === "content" && (
          <div className="h-full flex">
            {/* Document Preview */}
            <div className="flex-1 p-6 overflow-auto">
              <div className="max-w-4xl mx-auto">
                {file.type === "document" && (
                  <div className="bg-white dark:bg-gray-900 border rounded-lg p-8 shadow-sm">
                    <div className="prose dark:prose-invert max-w-none">
                      <h1>Project Proposal: Q4 Marketing Campaign</h1>
                      <p className="lead">
                        This document outlines our comprehensive strategy for the fourth quarter marketing campaign,
                        including budget allocation, timeline, and expected outcomes.
                      </p>

                      <h2>Executive Summary</h2>
                      <p>
                        Our Q4 marketing campaign aims to increase brand awareness and drive sales during the holiday
                        season. With a proposed budget of $50,000, we plan to implement a multi-channel approach
                        focusing on digital advertising, social media engagement, and content marketing.
                      </p>

                      <h2>Budget Breakdown</h2>
                      <ul>
                        <li>Digital Advertising: $30,000 (60%)</li>
                        <li>Content Creation: $10,000 (20%)</li>
                        <li>Social Media Management: $7,000 (14%)</li>
                        <li>Analytics & Tools: $3,000 (6%)</li>
                      </ul>

                      <h2>Timeline</h2>
                      <p>
                        The campaign will run from October 1st through December 31st, 2024, with key milestones
                        including Black Friday promotions and holiday-themed content releases.
                      </p>

                      <h2>Expected Outcomes</h2>
                      <p>
                        Based on previous campaign performance, we anticipate a 150% return on investment, with
                        projected revenue of $75,000 from the $50,000 investment.
                      </p>
                    </div>
                  </div>
                )}

                {file.type === "image" && (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center">
                      <div className="w-64 h-64 bg-muted rounded-lg flex items-center justify-center mb-4">
                        <Image className="w-16 h-16 text-muted-foreground" />
                      </div>
                      <p className="text-muted-foreground">Image preview would appear here</p>
                    </div>
                  </div>
                )}

                {file.type === "code" && (
                  <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto">
                    <pre>{`#!/usr/bin/env python3
"""
AI-powered file organizer
Automatically categorizes and organizes files using machine learning
"""

import os
import shutil
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

class FileOrganizer:
    def __init__(self, base_path):
        self.base_path = Path(base_path)
        self.vectorizer = TfidfVectorizer()
        self.clusterer = KMeans(n_clusters=5)
    
    def analyze_file_content(self, file_path):
        """Extract text content from file for analysis"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except:
            return ""
    
    def organize_files(self):
        """Main function to organize files into semantic groups"""
        files = list(self.base_path.rglob('*'))
        # Implementation continues...`}</pre>
                  </div>
                )}
              </div>
            </div>

            {/* Metadata Sidebar */}
            <div className="w-80 border-l p-4 overflow-auto">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">File Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Type:</span>
                      <Badge variant="outline">{file.type}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Size:</span>
                      <span>{file.size}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Modified:</span>
                      <span>{file.modified}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Group:</span>
                      <Badge variant="secondary">{file.vectorGroup}</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                      <Copy className="w-4 h-4 mr-2" />
                      Duplicate
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                      <Merge className="w-4 h-4 mr-2" />
                      Merge with...
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}

        {activeTab === "annotations" && (
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Annotations</h3>
              <Button size="sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Add Note
              </Button>
            </div>

            <Card>
              <CardContent className="p-4">
                <Textarea
                  placeholder="Add a new annotation..."
                  value={newAnnotation}
                  onChange={(e) => setNewAnnotation(e.target.value)}
                  className="mb-3"
                />
                <Button size="sm">Save Annotation</Button>
              </CardContent>
            </Card>

            <div className="space-y-3">
              {mockAnnotations.map((annotation) => (
                <Card key={annotation.id}>
                  <CardContent className="p-4">
                    <p className="text-sm mb-2">{annotation.text}</p>
                    <p className="text-xs text-muted-foreground">{annotation.timestamp}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === "ai-tools" && (
          <div className="p-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  AI Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isGeneratingSummary ? (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                    Generating summary...
                  </div>
                ) : (
                  <div>
                    <p className="text-sm mb-4">{mockSummary}</p>
                    <Button variant="outline" size="sm" onClick={generateSummary}>
                      Regenerate Summary
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Highlight className="w-5 h-5" />
                  Key Highlights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {mockHighlights.map((highlight, index) => (
                    <div
                      key={index}
                      className="p-2 bg-yellow-50 dark:bg-yellow-900/20 border-l-2 border-yellow-400 text-sm"
                    >
                      {highlight}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>AI Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Extract Key Information
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                  <Merge className="w-4 h-4 mr-2" />
                  Find Similar Documents
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Generate Questions
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
