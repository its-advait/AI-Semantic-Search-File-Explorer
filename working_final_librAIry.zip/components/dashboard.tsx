"use client"
import { Card, CardContent } from "@/components/ui/card"
import type React from "react"
import { useState } from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Search,
  Briefcase,
  Brain,
  Tag,
  Layers,
  Grid3X3,
  List,
  Info,
  FlipVerticalIcon as MoreVert,
  Star,
  Share,
  FileText,
  Folder,
} from "lucide-react"
import type { ViewType, FileItem } from "@/app/page"

interface DashboardProps {
  onViewChange: (view: ViewType) => void
  onFileSelect: (file: FileItem) => void
}

const recentFiles = [
  {
    id: "1",
    name: "Q4 Marketing Strategy.pdf",
    type: "document",
    size: "2.4 MB",
    modified: "2 hours ago",
    owner: "You",
    icon: FileText,
    thumbnail: "/placeholder.svg?height=120&width=120",
  },
  {
    id: "2",
    name: "Budget Analysis 2024",
    type: "folder",
    size: "12 items",
    modified: "Yesterday",
    owner: "You",
    icon: Folder,
    thumbnail: "/placeholder.svg?height=120&width=120",
  },
  {
    id: "3",
    name: "Team Photos",
    type: "folder",
    size: "45 items",
    modified: "3 days ago",
    owner: "You",
    icon: Folder,
    thumbnail: "/placeholder.svg?height=120&width=120",
  },
  {
    id: "4",
    name: "Project Timeline.xlsx",
    type: "document",
    size: "890 KB",
    modified: "1 week ago",
    owner: "You",
    icon: FileText,
    thumbnail: "/placeholder.svg?height=120&width=120",
  },
  {
    id: "5",
    name: "Meeting Notes - Jan",
    type: "document",
    size: "156 KB",
    modified: "2 weeks ago",
    owner: "You",
    icon: FileText,
    thumbnail: "/placeholder.svg?height=120&width=120",
  },
  {
    id: "6",
    name: "Design Assets",
    type: "folder",
    size: "23 items",
    modified: "3 weeks ago",
    owner: "You",
    icon: Folder,
    thumbnail: "/placeholder.svg?height=120&width=120",
  },
]

const quickAccess = [
  {
    name: "Work Documents",
    icon: Briefcase,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
    count: "234 files",
  },
  {
    name: "Personal Files",
    icon: Star,
    color: "text-yellow-600",
    bgColor: "bg-yellow-50",
    count: "156 files",
  },
  {
    name: "Shared with me",
    icon: Share,
    color: "text-green-600",
    bgColor: "bg-green-50",
    count: "89 files",
  },
  {
    name: "Recent",
    icon: FileText,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
    count: "67 files",
  },
]

export function Dashboard({ onViewChange, onFileSelect }: DashboardProps) {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onViewChange("search")
  }

  const handleFileClick = (file: any) => {
    const fileItem: FileItem = {
      id: file.id,
      name: file.name,
      type: file.type === "folder" ? "document" : "document",
      size: file.size,
      modified: file.modified,
      path: "/",
    }
    onFileSelect(fileItem)
    onViewChange("document")
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900">
      {/* Top Search Bar - Google Drive Style */}
      <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <form onSubmit={handleSearchSubmit} className="max-w-2xl">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search in LibrAIry"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 text-base rounded-full border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400 focus:ring-blue-500 dark:focus:ring-blue-400 bg-gray-50 dark:bg-gray-800"
              onFocus={() => onViewChange("search")}
            />
          </div>
        </form>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6">
          {/* Quick Access Section */}
          <div className="mb-8">
            <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Quick access</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {quickAccess.map((item, index) => (
                <Card
                  key={index}
                  className="cursor-pointer hover:shadow-md transition-shadow border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                  onClick={() => onViewChange("explorer")}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${item.bgColor} dark:bg-gray-700`}>
                        <item.icon className={`w-5 h-5 ${item.color} dark:text-gray-300`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100 truncate">{item.name}</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{item.count}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Recent Files Section */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Recent</h2>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  className={`p-2 ${viewMode === "grid" ? "bg-gray-100 dark:bg-gray-700" : ""}`}
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className={`p-2 ${viewMode === "list" ? "bg-gray-100 dark:bg-gray-700" : ""}`}
                >
                  <List className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <Info className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Files Grid/List */}
            {viewMode === "grid" ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                {recentFiles.map((file) => (
                  <Card
                    key={file.id}
                    className="cursor-pointer hover:shadow-md transition-all duration-200 border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 group"
                    onClick={() => handleFileClick(file)}
                  >
                    <CardContent className="p-3">
                      <div className="relative mb-3">
                        {/* File Thumbnail */}
                        <div className="aspect-square bg-gray-50 dark:bg-gray-700 rounded-lg flex items-center justify-center mb-2 group-hover:bg-gray-100 dark:group-hover:bg-gray-600 transition-colors">
                          <file.icon
                            className={`w-8 h-8 ${file.type === "folder" ? "text-blue-500" : "text-gray-600 dark:text-gray-400"}`}
                          />
                        </div>

                        {/* Action Menu */}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute top-1 right-1 p-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white dark:bg-gray-800 shadow-sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            // Handle menu click
                          }}
                        >
                          <MoreVert className="w-4 h-4" />
                        </Button>
                      </div>

                      <div>
                        <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100 truncate mb-1">
                          {file.name}
                        </h3>
                        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                          <span>{file.modified}</span>
                          <span>{file.size}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-1">
                {recentFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer group transition-colors"
                    onClick={() => handleFileClick(file)}
                  >
                    <div className="flex-shrink-0">
                      <file.icon
                        className={`w-6 h-6 ${file.type === "folder" ? "text-blue-500" : "text-gray-600 dark:text-gray-400"}`}
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100 truncate">{file.name}</h3>
                    </div>

                    <div className="flex items-center gap-6 text-sm text-gray-500 dark:text-gray-400">
                      <span className="w-20 text-right">{file.owner}</span>
                      <span className="w-24 text-right">{file.modified}</span>
                      <span className="w-16 text-right">{file.size}</span>
                    </div>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => {
                        e.stopPropagation()
                        // Handle menu click
                      }}
                    >
                      <MoreVert className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Suggested Actions */}
          <div className="mt-8">
            <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Suggested</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card
                className="cursor-pointer hover:shadow-md transition-shadow border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                onClick={() => onViewChange("explorer")}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-50 dark:bg-gray-700">
                      <Layers className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100">Explore by similarity</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">See your files grouped by content</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-md transition-shadow border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                onClick={() => onViewChange("search")}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-green-50 dark:bg-gray-700">
                      <Brain className="w-5 h-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100">Smart search</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Ask questions about your files</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-50 dark:bg-gray-700">
                      <Tag className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100">Auto-organize</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Let AI organize your files</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
